
<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "db_internship";
$msg="";

// Create a connection
$connection = mysqli_connect($servername, $username, $password, $database);

if (isset($_GET['deleteid'])) {
  $sno = $_GET['deleteid'];
  $dq=mysqli_query($connection, "delete from tbl_notes where sno='{$sno}'")   
 or die(mysqli_error($connection));
 if($dq)
   {
     echo "<script>alert(' are you sure to delete Note !!');</script>";
    }

}
 
if($_POST)
{
 $title =$_POST['title'];
 $description=$_POST['description'];

  $q=mysqli_query($connection,
  "insert into tbl_notes(title,description)  values('{$title}','{$description}')")
    or die("Error".mysqli_error($connection));
 if($q)
   {
     //echo "<script>alert('Record Added');</script>";
     $msg='<div class="alert alert-success" role="alert">
     Note is succsessfully Added!!! </div>';
    }
  //  header("location:inotes3.php");
 } 
?>
<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  <title>todo-Notes</title>
  </head>
  <body>
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#"><img src="/crud/logo.svg" height="28px" alt=""></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact Us</a>
        </li>

      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
   </nav>
   <?php
       echo $msg;
         ?>
  <div class="container my-4">
    <h2>Add a Note </h2>
    <form  method="POST">
      <div class="form-group">
        <label for="title">Note Title</label>
        <input type="text" class="form-control" id="title" name="title" aria-describedby="emailHelp" required>
      </div>
   <div class="form-group">
        <label for="desc">Note Description</label>
        <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
      </div>
      <button type="submit" class="btn btn-success">Add Note</button>
    </form>
    </div>
<div class="container my-4">
    <table class="table" id="mytable">
      <thead>
        <tr>
          <th scope="col">S.No</th>
          <th scope="col">Title</th>
          <th scope="col">Description</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "db_internship";
// Create a connection
$connection = mysqli_connect($servername, $username, $password, $database);
  $q=mysqli_query($connection, "select * from tbl_notes")  or die("Error".mysqli_error($connection));
  $sno = 0;
  while($row=mysqli_fetch_assoc($q)){
      $sno = $sno + 1;
   echo"<tr>";
   echo"<td>$sno</td>";
   echo"<td>{$row['title']}</td>";
   echo"<td>{$row['description']}</td>";
   //echo"<td><a href=''><img src='myimages/edit.png'>Edit</a>|<a href='inotes3.php?deleteid={$row['sno']}'><img src='myimages/delete.png' >Delete</a></td>";
  // echo"<td><a href='edit.php?id={$row['sno']}' ><img src='myimages/edit.png' style=width:'16px;' >Edit</a>|<a href='inotes3.php?deleteid={$row['sno']}'><img src='myimages/delete.png' style=width:'16px;' >Delete</a></td>"; 
  echo" <td><a href='edit.php?id={$row['sno']}'> <button class='edit btn btn-sm btn-primary'>Edit</button></a><a href='inotes3.php?deleteid={$row['sno']}'> <button class='delete btn btn-sm btn-secondary'>Delete</button></a></td></tr>";
   echo"</tr>"; 
}
?>
</tbody>
</table>
</div>
 <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
    crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
    crossorigin="anonymous"></script>
  <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
  <script>
    $(document).ready(function () {
      $('#mytable').DataTable();

    });
  </script>
